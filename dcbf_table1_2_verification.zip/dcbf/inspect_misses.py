"""For Table 2 realisations where the best pair was not the true pair, show where it was."""
import numpy as np
from sim import *
from dcbf import DCBF, powell_search
CONFIGS = {'A': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025]),
           'B': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055])}
MISSES = [('A',.5,9),('A',.5,11),('A',.5,14),('A',.5,1),('B',.75,1),('B',.75,4),('B',.75,5),('B',.5,1),('B',.5,5)]
for cfg, corr, rep in MISSES:
    src = [nearest(CONFIGS[cfg][0]), nearest(CONFIGS[cfg][1])]
    seed = int(1000*corr)*100 + rep + 7_000_000
    data, C, eps = simulate(src, np.array([[10.,20.],[10.,20.]]), 2.0, n_sig=5000, n_noise=5000,
                            rng=seed, phases=np.array([0, np.arccos(corr)]))
    bf = DCBF(L, C, eps)
    res, _, _ = powell_search(bf, 5, rng=seed+7)
    i, j, z = max(res, key=lambda r: r[2])
    d = np.linalg.norm(grid[[i, j]][:, None] - grid[src][None], axis=2) * 1000
    # nearest-true distance for each found dipole
    print(f"{cfg} r={corr} rep={rep}: found Z={z:.2f}, true Z={bf.pair(*src)['Z']:.2f}; "
          f"found dipoles' distance to true (mm): {d.min(1).round(1).tolist()}")
