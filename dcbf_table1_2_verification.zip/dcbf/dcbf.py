"""
Dual-Core Beamformer (DCBF) -- implementation of
Diwakar, Huang et al., "Dual-Core Beamformer for obtaining highly correlated
neuronal networks in MEG", NeuroImage 54 (2011) 253-263.

Contents
  * Forward model: spherical volume conductor (Sarvas 1987 formula) and a
    306-channel Vectorview-like array (102 magnetometers + 204 planar
    gradiometers).  The paper used a subject-specific BEM; no MRI is available
    here, so a sphere is used.  In a sphere the radial dipole is silent, which
    is exactly why the paper reduces each lead field to m x 2 by SVD.
  * Source grid: 7 mm cubic grid inside the upper part of the sphere.
  * DCBF (eqs 9-15): concatenated lead field Ldual=[L1 L2] (m x 4), K_dual,
    Q_dual, analytic optimal pseudo-Z, power, orientation/weighting and
    reconstructed time courses.
  * Modified Powell search (eq 16) with random restarts and a taboo list.
"""
import numpy as np

MU0 = 4e-7 * np.pi


# ----------------------------------------------------------------------------
# Forward model
# ----------------------------------------------------------------------------
def sarvas_field(r0, q, r):
    """Magnetic field B (T) at points r (n,3) from dipole q (A m) at r0 (3,)
    in a spherical conductor centred at the origin (Sarvas 1987)."""
    a_vec = r - r0
    a = np.linalg.norm(a_vec, axis=1)
    rn = np.linalg.norm(r, axis=1)
    adotr = np.einsum('ij,ij->i', a_vec, r)
    F = a * (rn * a + rn ** 2 - r0 @ r.T)
    c1 = a ** 2 / rn + adotr / a + 2 * a + 2 * rn
    c2 = a + 2 * rn + adotr / a
    gradF = c1[:, None] * r - c2[:, None] * r0[None, :]
    qxr0 = np.cross(q, r0)
    B = MU0 / (4 * np.pi * F[:, None] ** 2) * (
        F[:, None] * qxr0[None, :] - (r @ qxr0)[:, None] * gradF)
    return B


def make_sensor_array(n_loc=102, radius=0.115, zmin=-0.03, baseline=0.0168,
                      seed=0):
    """Helmet-like array: n_loc locations on a spherical cap; at each location
    one radial magnetometer and two orthogonal planar gradiometers."""
    # Fibonacci points restricted to the cap z >= zmin
    pts = []
    n_try = 4 * n_loc
    while True:
        i = np.arange(n_try) + 0.5
        phi = np.arccos(1 - 2 * i / n_try)
        theta = np.pi * (1 + 5 ** 0.5) * i
        p = np.c_[np.cos(theta) * np.sin(phi), np.sin(theta) * np.sin(phi),
                  np.cos(phi)] * radius
        p = p[p[:, 2] >= zmin]
        if len(p) >= n_loc:
            pts = p[:n_loc] if len(p) == n_loc else p[np.linspace(0, len(p) - 1, n_loc).astype(int)]
            break
        n_try += n_loc
    normals = pts / np.linalg.norm(pts, axis=1, keepdims=True)
    # two tangential unit vectors
    ref = np.array([0.0, 0.0, 1.0])
    t1 = np.cross(normals, ref)
    bad = np.linalg.norm(t1, axis=1) < 1e-6
    t1[bad] = np.cross(normals[bad], [1.0, 0, 0])
    t1 /= np.linalg.norm(t1, axis=1, keepdims=True)
    t2 = np.cross(normals, t1)
    return dict(pos=pts, nrm=normals, t1=t1, t2=t2, baseline=baseline)


def lead_field_3(r0, sens):
    """m x 3 lead field (channels x [qx,qy,qz]) for unit dipoles (1 A m).
    Magnetometers in fT per nAm, gradiometers in fT/cm per nAm."""
    pos, nrm, b = sens['pos'], sens['nrm'], sens['baseline']
    cols = []
    for k in range(3):
        q = np.zeros(3); q[k] = 1e-9                     # 1 nAm
        Bm = np.einsum('ij,ij->i', sarvas_field(r0, q, pos), nrm)
        g = []
        for t in (sens['t1'], sens['t2']):
            Bp = np.einsum('ij,ij->i', sarvas_field(r0, q, pos + t * b / 2), nrm)
            Bn = np.einsum('ij,ij->i', sarvas_field(r0, q, pos - t * b / 2), nrm)
            g.append((Bp - Bn) / (b * 100))              # T/cm
        cols.append(np.r_[Bm, g[0], g[1]] * 1e15)       # fT, fT/cm
    return np.array(cols).T


def make_grid(spacing=0.007, rmin=0.02, rmax=0.085, zmin=-0.025):
    ax = np.arange(-rmax, rmax + 1e-9, spacing)
    X, Y, Z = np.meshgrid(ax, ax, ax, indexing='ij')
    P = np.c_[X.ravel(), Y.ravel(), Z.ravel()]
    r = np.linalg.norm(P, axis=1)
    return P[(r >= rmin) & (r <= rmax) & (P[:, 2] >= zmin)]


def reduced_lead_fields(grid, sens):
    """SVD-reduce each m x 3 lead field to m x 2 (Huang et al. 2006).
    Returns L (p, m, 2) and the two tangential basis directions (p, 2, 3)."""
    p = len(grid)
    m = 3 * len(sens['pos'])
    L = np.empty((p, m, 2))
    basis = np.empty((p, 2, 3))
    for i, r0 in enumerate(grid):
        L3 = lead_field_3(r0, sens)
        U, S, Vt = np.linalg.svd(L3, full_matrices=False)
        L[i] = L3 @ Vt[:2].T            # = U[:, :2] * S[:2]
        basis[i] = Vt[:2]
    return L, basis


# ----------------------------------------------------------------------------
# Dual-core beamformer
# ----------------------------------------------------------------------------
class DCBF:
    """Holds C^-1 L and C^-1 eps C^-1 L for every grid node so that a whole
    profile f(r1, :) can be evaluated in one batched operation."""

    def __init__(self, L, C, eps):
        self.L = L                                    # (p, m, 2)
        self.p, self.m, self.k = L.shape
        Ci = np.linalg.inv(C)
        self.Ci = Ci
        Lflat = L.transpose(1, 0, 2).reshape(self.m, -1)   # m x 2p
        self.CiL_flat = Ci @ Lflat
        self.CiL = self.CiL_flat.reshape(self.m, self.p, self.k).transpose(1, 0, 2)
        W = Ci @ eps @ Ci
        self.WL_flat = W @ Lflat
        self.WL = self.WL_flat.reshape(self.m, self.p, self.k).transpose(1, 0, 2)
        # diagonal blocks  L_j' C^-1 L_j   and   L_j' C^-1 eps C^-1 L_j
        self.Qd = np.einsum('pmi,pmj->pij', L, self.CiL)
        self.Rd = np.einsum('pmi,pmj->pij', L, self.WL)
        self.n_eval = 0

    def _blocks(self, i, js):
        L, k = self.L, self.k
        n = len(js)
        if n == self.p:     # fast path: one BLAS call on the flat m x 2p arrays
            Q12 = (L[i].T @ self.CiL_flat).reshape(k, n, k).transpose(1, 0, 2)
            R12 = (L[i].T @ self.WL_flat).reshape(k, n, k).transpose(1, 0, 2)
        else:
            Q12 = np.einsum('mi,pmj->pij', L[i], self.CiL[js])
            R12 = np.einsum('mi,pmj->pij', L[i], self.WL[js])
        Q = np.empty((n, 2 * k, 2 * k)); R = np.empty_like(Q)
        Q[:, :k, :k] = self.Qd[i]; Q[:, k:, k:] = self.Qd[js]
        Q[:, :k, k:] = Q12;        Q[:, k:, :k] = Q12.transpose(0, 2, 1)
        R[:, :k, :k] = self.Rd[i]; R[:, k:, k:] = self.Rd[js]
        R[:, :k, k:] = R12;        R[:, k:, :k] = R12.transpose(0, 2, 1)
        return Q, R

    def profile(self, i):
        """f(i, j) = Z_opt^dual(i, j) for every j (eq 11).
        K = Q^-1 R  ->  Z = 1/min eig(K) = max generalised eig of (Q, R)."""
        js = np.arange(self.p)
        Q, R = self._blocks(i, js)
        z = np.full(self.p, -np.inf)
        ok = js != i
        Lr = np.linalg.cholesky(R[ok])
        Li = np.linalg.inv(Lr)
        M = Li @ Q[ok] @ Li.transpose(0, 2, 1)
        z[ok] = np.linalg.eigvalsh(M)[:, -1]
        self.n_eval += ok.sum()
        return z

    def pair(self, i, j):
        """Full DCBF solution for one dipole pair (eqs 10-14)."""
        Q, R = self._blocks(i, np.array([j]))
        Q, R = Q[0], R[0]
        K = np.linalg.solve(Q, R)                       # eq 10
        Z = 1.0 / np.min(np.real(np.linalg.eigvals(K)))  # eq 11
        w, U = np.linalg.eigh(Q)                         # eq 12
        P = 1.0 / w[0]                                   # eq 13
        O = U[:, 0]                                      # eq 14
        return dict(Z=Z, P=P, O=O)

    def reconstruct(self, i, j, b):
        """Eq 15: p(t) = O (P C^-1 Ldual O)^T b(t)  -> (4, T)."""
        s = self.pair(i, j)
        Ld = np.concatenate([self.L[i], self.L[j]], axis=1)
        w = s['P'] * self.Ci @ Ld @ s['O']
        return np.outer(s['O'], w @ b), s


# ----------------------------------------------------------------------------
# Modified Powell search with taboo list (eq 16)
# ----------------------------------------------------------------------------
def powell_search(bf, n_starts=1000, rng=None, max_iter=50):
    """Alternating maximisation of f(r1, r2) over grid indices, restarted from
    random r1.  A global taboo list stores every (r1, r2) visited; if a search
    reaches a pair that an earlier search traversed, it is interrupted and
    inherits that earlier search's end point (it would converge there)."""
    rng = np.random.default_rng(rng)
    visited = {}                        # (min,max) pair -> index of result
    results = []                        # (r1, r2, Z) end points
    outcome = np.empty(n_starts, int)   # which result each restart ended at
    profiles_per_start = np.empty(n_starts, int)
    for s in range(n_starts):
        r1 = int(rng.integers(bf.p))
        prof = bf.profile(r1); n_prof = 1
        r2 = int(np.argmax(prof))
        path = []
        inherited = None
        for _ in range(max_iter):
            key = (min(r1, r2), max(r1, r2))
            if key in visited:
                inherited = visited[key]; break
            path.append(key)
            prof = bf.profile(r2); n_prof += 1
            r1_new = int(np.argmax(prof))
            Z = float(prof[r1_new])
            if r1_new == r1:                # stable
                break
            r1, r2 = r2, r1_new
        if inherited is None:
            key = (min(r1, r2), max(r1, r2))
            results.append((key[0], key[1], Z))
            res_idx = len(results) - 1
        else:
            res_idx = inherited
        for k in path:
            visited[k] = res_idx
        outcome[s] = res_idx
        profiles_per_start[s] = n_prof
    return results, outcome, profiles_per_start


def brute_force(bf):
    """Exhaustive search over all p(p-1)/2 pairs (for verification)."""
    best = (-np.inf, -1, -1)
    for i in range(bf.p):
        z = bf.profile(i)
        z[:i + 1] = -np.inf
        j = int(np.argmax(z))
        if z[j] > best[0]:
            best = (z[j], i, j)
    return best
