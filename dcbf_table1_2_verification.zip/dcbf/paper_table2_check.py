"""Internal-consistency check of the numbers printed in Table 2 of the paper."""
import numpy as np
corr = np.array([1.0, 0.866, 0.75, 0.50])
rec = np.array([[9.4,18.8,9.2,18.4],[9.1,18.2,8.8,17.8],[8.9,17.7,8.5,17.1],[8.3,16.5,7.8,15.7]])
ori = np.array([[.502,.498],[.501,.497],[.501,.497],[.501,.497]])
Z = np.array([11.1,11.3,11.0,10.5]); true = np.array([10,20,10,20.])
ae = np.abs(rec-true)/true*100; oe = np.abs(ori-.5)/.5*100
print('amp err per row', ae.mean(1).round(2), ' all-entries mean/sd', ae.mean().round(2), ae.std().round(2),
      ' row-mean sd', ae.mean(1).std().round(2), ae.mean(1).std(ddof=1).round(2), '(paper 12.5, 5.1)')
print('ori err per row', oe.mean(1).round(2), ' mean/sd', oe.mean().round(2), oe.std().round(2), oe.std(ddof=1).round(2), '(paper 0.40, 0.18)')
r = np.corrcoef(corr, ae.mean(1))[0,1]; print('r^2 amp err vs corr (4 rows)', round(r*r,5), '(paper 0.99905)')
r = np.corrcoef(corr[1:], Z[1:])[0,1]; print('r^2 Z vs corr (non-perfect)', round(r*r,5), '(paper 0.99998)')
print('amplitude ratio d1/d2 implied', (rec[:,0]/rec[:,1]).round(3), (rec[:,2]/rec[:,3]).round(3), 'vs printed', ori.tolist())
