import numpy as np, time
from dcbf import *
t=time.time()
sens = make_sensor_array()
grid = make_grid()
print('grid points', len(grid))
L, basis = reduced_lead_fields(grid, sens)
print('lead fields', L.shape, time.time()-t)
np.savez('model.npz', grid=grid, L=L, basis=basis, pos=sens['pos'])
# sanity: radial dipole silent, field magnitudes
L3 = lead_field_3(np.array([0.,0.06,0.03]), sens)
print('singular values', np.linalg.svd(L3, compute_uv=False))
print('max |B| mag fT/nAm', np.abs(L3[:102]).max(), ' grad fT/cm/nAm', np.abs(L3[102:]).max())
