"""Reproduce Table 2 (DCBF performance under varying intra-pair correlation).
Correlation is set by phase-shifting dipole 2: for equal-frequency sinusoids
the correlation coefficient is cos(phi), so phi = arccos(r)."""
import sys, time, json, numpy as np
from sim import *

N_SIG = int(sys.argv[1]); N_REAL = int(sys.argv[2]); DO_BRUTE = sys.argv[3] == '1'
REP0 = int(sys.argv[4]); CFG = sys.argv[5]
import os
CORRS = [float(x) for x in os.environ.get("CORRS", "1.0,0.866,0.75,0.50").split(",")]
SNR = 2.0
MOM = np.array([[10., 20.], [10., 20.]])
CONFIGS = {'A': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025]),
           'B': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055]),
           'C': ([0.020, 0.030, 0.065], [0.050, -0.030, 0.030])}
src = [nearest(CONFIGS[CFG][0]), nearest(CONFIGS[CFG][1])]
true_key = tuple(sorted(src))
t = np.arange(N_SIG) / FS
for corr in CORRS:
    phi = np.arccos(corr)
    emp_r = np.corrcoef(np.sin(2*np.pi*30*t), np.sin(2*np.pi*30*t + phi))[0, 1]
    for rep in range(REP0, REP0 + N_REAL):
        seed = int(1000 * corr) * 100 + rep + 7_000_000
        data, C, eps = simulate(src, MOM, SNR, n_sig=N_SIG, n_noise=N_SIG, rng=seed,
                                phases=np.array([0.0, phi]))
        bf = DCBF(L, C, eps)
        t0 = time.time()
        res, outcome, nprof = powell_search(bf, 1000, rng=seed + 7)
        t_search = time.time() - t0
        best = max(range(len(res)), key=lambda k: res[k][2])
        found = (res[best][0], res[best][1]) == true_key
        idx_true = [k for k, r in enumerate(res) if (r[0], r[1]) == true_key]
        hits = int(np.isin(outcome, idx_true).sum())
        brute_ok = None
        if DO_BRUTE and rep == REP0:
            zb, bi, bj = brute_force(bf); brute_ok = (bi, bj) == true_key
        p, sol = bf.reconstruct(src[0], src[1], data)
        amps = amp_at(p, 30.0)
        # also: true per-source amplitude seen by a single-time-course model
        row = dict(cfg=CFG, corr=corr, emp_r=emp_r, rep=rep, found_by_powell=bool(found),
                   brute_ok=brute_ok, n_local_maxima=len(res), hits=hits,
                   sec_per_restart=t_search / 1000, amp=amps.round(3).tolist(),
                   ratio=[amps[0]/amps[1], amps[2]/amps[3]], Z=sol['Z'],
                   best_Z=res[best][2])
        print(json.dumps(row), flush=True)
