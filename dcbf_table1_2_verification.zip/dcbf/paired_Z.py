"""Paired check of pseudo-Z vs correlation: identical noise for every correlation,
so only the phase of dipole 2 changes. Z evaluated at the true pair."""
import numpy as np
from sim import *
from dcbf import DCBF
CONFIGS = {'A': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025]),
           'B': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055]),
           'C': ([0.020, 0.030, 0.065], [0.050, -0.030, 0.030])}
corrs = [1.0, 0.866, 0.75, 0.5]
for cfg, (x1, x2) in CONFIGS.items():
    src = [nearest(x1), nearest(x2)]
    Z = np.zeros((20, 4))
    for s in range(20):
        for k, c in enumerate(corrs):
            _, C, eps = simulate(src, np.array([[10.,20.],[10.,20.]]), 2.0, n_sig=5000, n_noise=5000,
                                 rng=900 + s, phases=np.array([0, np.arccos(c)]))
            Z[s, k] = DCBF(L[src], C, eps).pair(0, 1)['Z']
    m = Z.mean(0); se = Z.std(0, ddof=1) / np.sqrt(len(Z))
    print(cfg, ' '.join(f"r={c}: {a:.2f}±{b:.2f}" for c, a, b in zip(corrs, m, se)),
          '| paired diff Z(0.5)-Z(0.866):', f"{(Z[:,3]-Z[:,1]).mean():.2f}±{(Z[:,3]-Z[:,1]).std(ddof=1)/np.sqrt(20):.2f}")
