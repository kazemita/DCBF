"""Aggregate Table 2 logs and compare with the paper."""
import json, sys, numpy as np

PAPER = {1.0: ([9.4, 18.8, 9.2, 18.4], [.502, .498], 21.7, 1.015, 11.1),
         0.866: ([9.1, 18.2, 8.8, 17.8], [.501, .497], 1, 0.034, 11.3),
         0.75: ([8.9, 17.7, 8.5, 17.1], [.501, .497], 1, 0.033, 11.0),
         0.50: ([8.3, 16.5, 7.8, 15.7], [.501, .497], 1, 0.035, 10.5)}
TRUE = np.array([10, 20, 10, 20.])
rows = [json.loads(l) for f in sys.argv[1:] for l in open(f)]
cfgs = sorted({r['cfg'] for r in rows})
summary = []
for cfg in cfgs:
    print(f"\n=== source pair {cfg} ===")
    for corr in sorted(PAPER, reverse=True):
        R = [r for r in rows if r['cfg'] == cfg and r['corr'] == corr]
        if not R:
            continue
        A = np.array([r['amp'] for r in R]); Ra = np.array([r['ratio'] for r in R])
        hits = sum(r['hits'] for r in R)
        spr = np.mean([r['sec_per_restart'] for r in R])
        srch = 1000 * len(R) / hits if hits else np.inf
        brute = [r['brute_ok'] for r in R if r['brute_ok'] is not None]
        d = dict(cfg=cfg, corr=corr, n=len(R), brute=f"{sum(brute)}/{len(brute)}",
                 powell=f"{sum(r['found_by_powell'] for r in R)}/{len(R)}",
                 amp=A.mean(0).tolist(), ratio=Ra.mean(0).tolist(),
                 amp_err=float((np.abs(A - TRUE) / TRUE).mean() * 100),
                 ori_err=float((np.abs(Ra - .5) / .5).mean() * 100),
                 searches=srch, minutes=srch * spr / 60,
                 Z=float(np.mean([r['Z'] for r in R])), Zsd=float(np.std([r['Z'] for r in R])),
                 n_maxima=float(np.mean([r['n_local_maxima'] for r in R])))
        summary.append(d)
        p = PAPER[corr]
        print(f"r={corr:5} n={d['n']} brute {d['brute']} powell {d['powell']} | amp "
              f"{' '.join(f'{a:5.2f}' for a in d['amp'])} (paper {' '.join(map(str, p[0]))}) | "
              f"ratio {d['ratio'][0]:.3f} {d['ratio'][1]:.3f} (paper {p[1][0]} {p[1][1]}) | "
              f"amp err {d['amp_err']:.1f}% ori err {d['ori_err']:.2f}% | "
              f"searches {d['searches']:.2f} (paper {p[2]}) | min {d['minutes']:.4f} (paper {p[3]}) | "
              f"Z {d['Z']:.2f}±{d['Zsd']:.2f} (paper {p[4]}) | maxima {d['n_maxima']:.0f}")
    S = [d for d in summary if d['cfg'] == cfg]
    c = np.array([d['corr'] for d in S]); ae = np.array([d['amp_err'] for d in S])
    z = np.array([d['Z'] for d in S])
    if len(S) == 4:
        r1 = np.corrcoef(c, ae)[0, 1] ** 2; r2 = np.corrcoef(c[1:], z[1:])[0, 1] ** 2
        print(f"r^2 amp-err vs corr = {r1:.5f} (paper 0.99905); r^2 Z vs corr (non-perfect) = {r2:.5f} (paper 0.99998)")
json.dump(summary, open("summary_table2.json", "w"), indent=1, default=float)
