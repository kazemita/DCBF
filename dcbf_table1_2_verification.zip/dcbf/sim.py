import numpy as np, time
from dcbf import DCBF, powell_search, brute_force

M = np.load('model.npz'); grid, L, basis = M['grid'], M['L'], M['basis']
FS = 1000

def nearest(x): return int(np.argmin(np.linalg.norm(grid - x, axis=1)))

def simulate(src, moments, snr, freq=30.0, n_sig=1000, n_noise=1000, rng=None,
             phases=None, extra=None):
    """src: grid indices; moments: (n_src,2) nAm along the 2 SVD basis dirs.
    SNR = total signal power / total added noise power (sensor domain)."""
    rng = np.random.default_rng(rng)
    t = np.arange(n_sig) / FS
    phases = np.zeros(len(src)) if phases is None else phases
    b = np.zeros((L.shape[1], n_sig))
    for s, mom, ph in zip(src, moments, phases):
        b += np.outer(L[s] @ mom, np.sin(2*np.pi*freq*t + ph))
    if extra is not None: b += extra(t)
    sigma = np.sqrt(np.mean(b**2) / snr)
    data = b + sigma * rng.standard_normal(b.shape)
    noise = sigma * rng.standard_normal((L.shape[1], n_noise))
    C = data @ data.T / n_sig
    eps = noise @ noise.T / n_noise
    return data, C, eps

def amp_at(x, f):
    X = np.fft.rfft(x, axis=-1); fr = np.fft.rfftfreq(x.shape[-1], 1/FS)
    return 2*np.abs(X[..., np.argmin(abs(fr-f))]) / x.shape[-1]
