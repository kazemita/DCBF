"""Internal-consistency check of the numbers printed in Table 1 of the paper."""
import numpy as np
snr = [4.0, 3.0, 2.0, 1.0, 0.50, 0.33, 0.25]
rec = np.array([[9.4,18.7,9.2,18.5],[9.4,18.7,9.2,18.5],[9.4,18.8,9.2,18.4],
                [9.5,18.9,9.1,18.3],[9.7,19.3,8.9,18.1],[9.9,19.5,8.7,17.8],
                [10.1,19.8,8.5,17.6]])
ori = np.array([[.501,.498],[.501,.498],[.502,.497],[.503,.495],[.505,.491],[.507,.487],[.509,.483]])
srch = np.array([31.3,28.6,21.7,14.3,5.4,2.3,1.4]); tmin = np.array([1.502,1.411,1.015,.716,.257,.102,.059])
Z = [11.3,11.2,11.1,10.9,10.3,9.9,9.4]
true = np.array([10,20,10,20.])
amp_err = np.abs(rec-true)/true*100
ori_err = np.abs(ori-0.5)/0.5*100
print('SNR  amp_err(mean %)  ori_err(mean %)  ratio-from-amps   sec/search  Z')
for k,s in enumerate(snr):
    print(f'{s:4} {amp_err[k].mean():6.2f}   {ori_err[k].mean():6.2f}    '
          f'{rec[k,0]/rec[k,1]:.3f} {rec[k,2]/rec[k,3]:.3f}   vs printed {ori[k]}   {tmin[k]*60/srch[k]:5.2f}  {Z[k]}')
print('amp err range', amp_err.mean(1).min(), amp_err.mean(1).max(), '(paper: 6.8-7.2%)')
print('ori err range', ori_err.mean(1).min(), ori_err.mean(1).max(), '(paper: 0.27-2.56%)')
x = np.array(snr)
for name,y in [('searches',srch),('time',tmin)]:
    r = np.corrcoef(x,y)[0,1]; print(f'r^2 linear {name} vs SNR = {r*r:.4f}')
