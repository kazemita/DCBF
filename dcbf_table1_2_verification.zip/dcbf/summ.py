import json,sys
for f in sys.argv[1:]:
  print(f)
  for l in open(f):
    r=json.loads(l); print(r['snr'],r['rep'],'powell:',r['found_by_powell'],'brute:',r['brute_ok'],'hits',r['hits'],'nmax',r['n_local_maxima'],[round(a,2) for a in r['amp']],[round(x,3) for x in r['ratio']],'Z',round(r['Z'],3),'bestZ',round(r['best_Z'],3), 's/restart',round(r['sec_per_restart'],3))
