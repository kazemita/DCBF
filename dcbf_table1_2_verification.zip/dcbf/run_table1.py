"""Reproduce Table 1 (DCBF performance under varying SNR)."""
import sys, time, json, numpy as np
from sim import *

N_SIG = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
N_REAL = int(sys.argv[2]) if len(sys.argv) > 2 else 3
DO_BRUTE = (sys.argv[3] == '1') if len(sys.argv) > 3 else True
REP0 = int(sys.argv[4]) if len(sys.argv) > 4 else 0
TAG = sys.argv[5] if len(sys.argv) > 5 else ''
SNRS = [4.0, 3.0, 2.0, 1.0, 0.50, 0.33, 0.25]
MOM = np.array([[10., 20.], [10., 20.]])       # nAm, (dir1, dir2) per dipole
CONFIGS = {'A': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025]),   # bilateral temporal
           'B': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055]),   # L frontal / R parietal
           'C': ([0.020, 0.030, 0.065], [0.050, -0.030, 0.030])}    # same hemisphere
CFG = sys.argv[6] if len(sys.argv) > 6 else 'A'
src = [nearest(CONFIGS[CFG][0]), nearest(CONFIGS[CFG][1])]
print('# config', CFG, 'src', src, grid[src].round(3).tolist(), file=sys.stderr)
true_key = tuple(sorted(src))
rows = []
for snr in SNRS:
    for rep in range(REP0, REP0 + N_REAL):
        seed = int(1000 * snr) * 100 + rep
        data, C, eps = simulate(src, MOM, snr, n_sig=N_SIG, n_noise=N_SIG, rng=seed)
        bf = DCBF(L, C, eps)
        t0 = time.time()
        res, outcome, nprof = powell_search(bf, 1000, rng=seed + 7)
        t_search = time.time() - t0
        best = max(range(len(res)), key=lambda k: res[k][2])
        found = (res[best][0], res[best][1]) == true_key
        idx_true = [k for k, r in enumerate(res) if (r[0], r[1]) == true_key]
        hits = int(np.isin(outcome, idx_true).sum())
        if DO_BRUTE and rep == REP0:
            zb, bi, bj = brute_force(bf); brute_ok = (bi, bj) == true_key
        else:
            brute_ok = None
        p, sol = bf.reconstruct(src[0], src[1], data)
        amps = amp_at(p, 30.0)                                  # 4 components
        # sign of eigenvector is arbitrary -> amplitudes are magnitudes
        row = dict(snr=snr, rep=rep, found_by_powell=bool(found), brute_ok=brute_ok,
                   n_local_maxima=len(res), hits=hits,
                   avg_searches=1000 / hits if hits else np.inf,
                   sec_per_restart=t_search / 1000,
                   avg_time_min=(1000 / hits) * t_search / 1000 / 60 if hits else np.inf,
                   amp=amps.round(3).tolist(),
                   ratio=[amps[0] / amps[1], amps[2] / amps[3]],
                   Z=sol['Z'], best_Z=res[best][2])
        rows.append(row)
        print(json.dumps(row), flush=True)
json.dump(rows, open(f'table1_N{N_SIG}{TAG}.json', 'w'), indent=1)
