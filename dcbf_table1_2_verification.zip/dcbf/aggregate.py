"""Aggregate simulation logs into a Table-1 style comparison with the paper."""
import json, sys, numpy as np

PAPER = {  # SNR: (rec amps d1x, d1y, d2x, d2y), (ratio d1, d2), searches, time(min), Z
    4.0: ([9.4, 18.7, 9.2, 18.5], [.501, .498], 31.3, 1.502, 11.3),
    3.0: ([9.4, 18.7, 9.2, 18.5], [.501, .498], 28.6, 1.411, 11.2),
    2.0: ([9.4, 18.8, 9.2, 18.4], [.502, .497], 21.7, 1.015, 11.1),
    1.0: ([9.5, 18.9, 9.1, 18.3], [.503, .495], 14.3, 0.716, 10.9),
    0.50: ([9.7, 19.3, 8.9, 18.1], [.505, .491], 5.4, 0.257, 10.3),
    0.33: ([9.9, 19.5, 8.7, 17.8], [.507, .487], 2.3, 0.102, 9.9),
    0.25: ([10.1, 19.8, 8.5, 17.6], [.509, .483], 1.4, 0.059, 9.4),
}
TRUE = np.array([10, 20, 10, 20.])

rows = [json.loads(l) for f in sys.argv[2:] for l in open(f)]
out = []
print(f"Results for {sys.argv[1]}")
hdr = ("SNR | n | located (brute) | located (Powell best) | rec. amp nAm d1 (x,y) d2 (x,y) | "
       "ratio d1, d2 | amp err % | ori err % | restarts per hit | min to find | Z")
print(hdr)
for snr in sorted(PAPER, reverse=True):
    R = [r for r in rows if r['snr'] == snr]
    if not R:
        continue
    A = np.array([r['amp'] for r in R]); Ra = np.array([r['ratio'] for r in R])
    hits = sum(r['hits'] for r in R)
    spr = np.mean([r['sec_per_restart'] for r in R])
    searches = 1000 * len(R) / hits if hits else np.inf
    brute = [r['brute_ok'] for r in R if r['brute_ok'] is not None]
    d = dict(snr=snr, n=len(R),
             brute=f"{sum(brute)}/{len(brute)}",
             powell=f"{sum(r['found_by_powell'] for r in R)}/{len(R)}",
             amp=A.mean(0), ratio=Ra.mean(0),
             amp_err=(np.abs(A - TRUE) / TRUE).mean() * 100,
             ori_err=(np.abs(Ra - 0.5) / 0.5).mean() * 100,
             searches=searches, minutes=searches * spr / 60,
             Z=np.mean([r['Z'] for r in R]), Zsd=np.std([r['Z'] for r in R]))
    out.append(d)
    p = PAPER[snr]
    print(f"{snr:4} | {d['n']} | {d['brute']} | {d['powell']} | "
          f"{' '.join(f'{a:5.2f}' for a in d['amp'])} (paper {' '.join(map(str, p[0]))}) | "
          f"{d['ratio'][0]:.3f} {d['ratio'][1]:.3f} (paper {p[1][0]} {p[1][1]}) | "
          f"{d['amp_err']:.2f} | {d['ori_err']:.2f} | "
          f"{d['searches']:.1f} (paper {p[2]}) | {d['minutes']:.3f} (paper {p[3]}) | "
          f"{d['Z']:.2f}±{d['Zsd']:.2f} (paper {p[4]})")
json.dump([{k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in d.items()} for d in out],
          open(f"summary_{sys.argv[1]}.json", "w"), indent=1)
