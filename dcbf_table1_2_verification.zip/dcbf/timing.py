import time, numpy as np
from sim import *
src=[nearest([-0.055,0.005,0.025]), nearest([0.055,-0.005,0.025])]
data,C,eps = simulate(src, np.array([[10,20],[10,20]]), 2.0, rng=1)
bf=DCBF(L,C,eps)
t=time.time()
for k in range(20): z=bf.profile(k)
print('profile ms', (time.time()-t)/20*1000)
z=bf.profile(src[0]); print('argmax', np.argmax(z), 'true', src[1], z.max(), np.sort(z)[-5:])
print(bf.pair(*src))
