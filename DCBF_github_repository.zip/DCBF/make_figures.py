"""Figures for the NeuroImage commentary (Elsevier: 190 mm double column, Arial ~7-8 pt)."""
import json, glob, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BLUE, ORANGE, AQUA, GREY, INK, MUTED = '#2a78d6', '#eb6834', '#1baf7a', '#6f6e69', '#0b0b0b', '#52514e'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.linewidth': 0.6,
                     'axes.edgecolor': MUTED, 'axes.labelcolor': INK, 'xtick.color': MUTED, 'ytick.color': MUTED,
                     'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'axes.spines.top': False,
                     'axes.spines.right': False, 'legend.frameon': False, 'savefig.dpi': 600})
MM = 1 / 25.4
OUT = 'figures/'

def panel_label(ax, s):
    ax.text(-0.16, 1.04, s, transform=ax.transAxes, fontsize=10, fontweight='bold', va='bottom', color=INK)

# ------------------------------------------------------------------ data: Table 1 searches
rows = []
for f in ['results/log_N5000.txt', 'results/log_N5000_reps.txt', 'results/log_N5000_B.txt', 'results/log_N5000_C.txt',
          'results/log_extraA.txt', 'results/log_extraB.txt', 'results/log_extraC.txt']:
    if not __import__('os').path.exists(f):
        continue
    for l in open(f):
        rows.append(json.loads(l))
SNRS = [4.0, 3.0, 2.0, 1.0, 0.5, 0.33, 0.25]
PAPER_SEARCH = [31.3, 28.6, 21.7, 14.3, 5.4, 2.3, 1.4]
summary_t1 = {}
for s in SNRS:
    R = [r for r in rows if r['snr'] == s]
    hits = np.array([r['hits'] for r in R])
    summary_t1[s] = dict(n=len(R), fails=int((hits == 0).sum()), pooled=1000 * len(R) / max(hits.sum(), 1),
                         per_run=[1000 / h if h else None for h in hits],
                         search_fail=int(sum(1 for r in R if r['hits'] == 0 and r['Z'] > r['best_Z'])))

# ------------------------------------------------------------------ Figure 1
fig, axs = plt.subplots(1, 2, figsize=(180 * MM, 68 * MM), gridspec_kw=dict(wspace=0.38))
ax = axs[0]
x = np.arange(len(SNRS))
rng = np.random.default_rng(3)
CEIL = 3000
for i, s in enumerate(SNRS):
    pr = summary_t1[s]['per_run']
    ok = [v for v in pr if v is not None]
    ax.scatter(i + rng.uniform(-0.13, 0.13, len(ok)), ok, s=7, color=BLUE, alpha=0.35, lw=0, zorder=2)
    nf = summary_t1[s]['fails']
    if nf:
        ax.scatter([i], [CEIL], marker='^', s=22, facecolor='white', edgecolor=BLUE, lw=0.9, zorder=3)
        ax.text(i + 0.18, CEIL, f'{nf}/{summary_t1[s]["n"]}', va='center', fontsize=6.5, color=INK)
ax.plot(x, [summary_t1[s]['pooled'] for s in SNRS], '-o', color=BLUE, ms=4, lw=1.4, zorder=4)
ax.plot(x, PAPER_SEARCH, '--s', color=ORANGE, ms=3.6, lw=1.4, mfc='white', mew=1.1, zorder=4)
ax.set_yscale('log'); ax.set_ylim(0.8, 6000)
ax.set_xticks(x, [f'{s:g}' for s in SNRS]); ax.set_xlabel('SNR')
ax.set_ylabel('Restarts needed per success')
ax.axhline(1000, color=GREY, lw=0.5, ls=':')
ax.text(6.45, 1000 * 1.12, '1,000 restarts', ha='right', va='bottom', fontsize=6.3, color=MUTED)
ax.text(0.18, CEIL * 1.35, 'true pair not found', fontsize=6.3, color=MUTED, ha='left')
ax.text(3.15, summary_t1[1.0]['pooled'] * 1.25, 'This study', color=INK, fontsize=7, ha='left', va='bottom')
ax.text(4.1, 9.0, 'Paper (Table 1)', color=INK, fontsize=7, ha='left', va='bottom')
panel_label(ax, 'A')

ax = axs[1]
paper_Z = np.array([11.3, 11.0, 10.5]); corr = np.array([0.866, 0.75, 0.5])
Zs = np.concatenate([np.load(f'results/pairedZ_{c}.npy') for c in 'ABC'])        # (60, 4): r = 1, .866, .75, .5
d = Zs[:, 1:] - Zs[:, [1]]
mean = d.mean(0); se = d.std(0, ddof=1) / np.sqrt(len(d))
ax.axhline(0, color=GREY, lw=0.5)
ax.errorbar(corr * 100, mean, yerr=1.96 * se, fmt='-o', color=BLUE, ms=4, lw=1.4, capsize=2, elinewidth=0.8, zorder=3)
ax.plot(corr * 100, paper_Z - paper_Z[0], '--s', color=ORANGE, ms=3.6, lw=1.4, mfc='white', mew=1.1, zorder=3)
ax.set_xlim(90, 45); ax.set_xticks([86.6, 75, 50], ['86.6', '75', '50'])
ax.set_xlabel('Correlation between the two sources (%)')
ax.set_ylabel('Change in pseudo-Z from 86.6% correlation')
ax.text(57, mean[-1] + 0.05, 'This study', fontsize=7, color=INK, ha='right', va='bottom')
ax.text(52, (paper_Z - paper_Z[0])[-1] - 0.12, 'Paper (Table 2)', fontsize=7, color=INK, ha='center', va='top')
ax.set_ylim(-1.1, 0.75)
panel_label(ax, 'B')
fig.savefig(OUT + 'Figure1.pdf', bbox_inches='tight'); fig.savefig(OUT + 'Figure1.png', bbox_inches='tight', dpi=400)
fig.savefig(OUT + 'Figure1.tif', bbox_inches='tight', dpi=600, pil_kwargs={'compression': 'tiff_lzw'})

# ------------------------------------------------------------------ Figure 2
A = [json.loads(l) for l in open('results/amp_vs_length.txt')]
Ns = np.array([1000, 2000, 3000, 5000, 10000, 20000]); m = 306
fig, axs = plt.subplots(1, 2, figsize=(180 * MM, 68 * MM), gridspec_kw=dict(wspace=0.38))
ax = axs[0]
NN = np.geomspace(800, 25000, 200)
for r, col, mk, lab in ((1.0, BLUE, 'o', 'r = 1'), (0.5, AQUA, 'D', 'r = 0.5')):
    mu = np.array([np.mean([a['ratio'] for a in A if a['N'] == n and a['r'] == r]) for n in Ns])
    sd = np.array([np.std([a['ratio'] for a in A if a['N'] == n and a['r'] == r]) for n in Ns])
    ax.plot(NN, (1 - m / NN) * np.sqrt((1 + r) / 2), '--', color=GREY, lw=0.9, zorder=2)
    ax.errorbar(Ns, mu, yerr=sd, fmt=mk, color=col, ms=4 if mk == 'o' else 3.5, capsize=1.5, elinewidth=0.8, zorder=3)
    ax.text(26000, (1 - m / 20000) * np.sqrt((1 + r) / 2), lab, fontsize=7, color=INK, va='center')
ax.axhspan(0.92, 0.94, color=ORANGE, alpha=0.22, lw=0, zorder=1)
ax.text(850, 0.952, 'Paper, Table 1 (both dipoles)', fontsize=6.5, color=INK, va='bottom')
ax.text(1200, 0.50, 'dashed: (1 − m/N)·√((1 + r)/2), m = 306', fontsize=6.5, color=MUTED)
ax.set_xscale('log'); ax.set_xlim(800, 40000); ax.set_ylim(0.45, 1.02)
ax.set_xticks([1000, 2000, 5000, 10000, 20000], ['1,000', '2,000', '5,000', '10,000', '20,000'])
ax.set_xlabel('Number of samples, N'); ax.set_ylabel('Reconstructed / true amplitude')
panel_label(ax, 'B' if False else 'A')

ax = axs[1]
rr = np.linspace(0.45, 1.0, 100)
ax.plot(rr * 100, np.sqrt((1 + rr) / 2), '--', color=GREY, lw=0.9, zorder=2)
ax.text(68, np.sqrt((1 + 0.68) / 2) + 0.006, '√((1 + r)/2)', fontsize=7, color=MUTED, ha='left', va='bottom', rotation=-22)
paper = {'Dipole 1': [[9.4, 18.8], [9.1, 18.2], [8.9, 17.7], [8.3, 16.5]],
         'Dipole 2': [[9.2, 18.4], [8.8, 17.8], [8.5, 17.1], [7.8, 15.7]]}
c4 = np.array([1.0, 0.866, 0.75, 0.5])
for k, (lab, v) in enumerate(paper.items()):
    v = np.array(v); rel = v / v[0]
    for j in range(2):
        ax.scatter(c4 * 100 + (k - 0.5) * 1.2, rel[:, j], marker='s' if k == 0 else '^', s=16 if k == 0 else 20,
                   facecolor='white', edgecolor=ORANGE, lw=1.0, zorder=3)
S2 = json.load(open('results/summary_table2.json'))
ours = []
for c in c4:
    R = [d_ for d_ in S2 if d_['corr'] == c]; n = np.array([d_['n'] for d_ in R])
    ours.append(np.average([d_['amp'] for d_ in R], axis=0, weights=n))
ours = np.array(ours); rel = ours / ours[0]
ax.scatter(np.repeat(c4 * 100, 4), rel.ravel(), marker='o', s=12, color=BLUE, zorder=4, lw=0)
ax.set_xlim(103, 45); ax.set_xticks([100, 86.6, 75, 50], ['100', '86.6', '75', '50'])
ax.set_ylim(0.80, 1.03)
ax.set_xlabel('Correlation between the two sources (%)')
ax.set_ylabel('Amplitude relative to 100% correlation')
ax.scatter([], [], marker='o', s=12, color=BLUE, label='This study (all components)')
ax.scatter([], [], marker='s', s=16, facecolor='white', edgecolor=ORANGE, label='Paper, dipole 1')
ax.scatter([], [], marker='^', s=20, facecolor='white', edgecolor=ORANGE, label='Paper, dipole 2')
ax.legend(loc='lower left', fontsize=6.5, handletextpad=0.3, borderaxespad=0.2)
panel_label(ax, 'B')
fig.savefig(OUT + 'Figure2.pdf', bbox_inches='tight'); fig.savefig(OUT + 'Figure2.png', bbox_inches='tight', dpi=400)
fig.savefig(OUT + 'Figure2.tif', bbox_inches='tight', dpi=600, pil_kwargs={'compression': 'tiff_lzw'})

json.dump({str(k): {kk: vv for kk, vv in v.items() if kk != 'per_run'} for k, v in summary_t1.items()},
          open(OUT + 'fig1_summary.json', 'w'), indent=1)
print(json.dumps({str(k): {kk: (round(vv, 1) if isinstance(vv, float) else vv) for kk, vv in v.items() if kk != 'per_run'} for k, v in summary_t1.items()}))
print('paired dZ mean', mean.round(3), 'se', se.round(3))
