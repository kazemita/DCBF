"""Combine head-to-head results (compare.txt) with the DCBF logs on the same seeds."""
import json, numpy as np

TRUE = np.array([10, 20, 10, 20.])
dcbf = {}
for f, cfg in [('results/log_N5000.txt', 'A'), ('results/log_N5000_reps.txt', 'A'),
               ('results/log_N5000_B.txt', 'B'), ('results/log_N5000_C.txt', 'C')]:
    for l in open(f):
        r = json.loads(l); dcbf[(1, cfg, r['snr'], 1.0, r['rep'])] = r
for f in ['results/t2_A.txt', 'results/t2_A_extra.txt', 'results/t2_B.txt', 'results/t2_B_extra.txt', 'results/t2_C.txt', 'results/t2_C_extra.txt']:
    for l in open(f):
        r = json.loads(l); dcbf[(2, r['cfg'], 2.0, r['corr'], r['rep'])] = r

rows = [json.loads(l) for l in open('results/compare.txt')]
M = ['RS', 'JP', 'EX2', 'EX2r10', 'ES3', 'ES4']
summary = []
for table, key in [(1, 'snr'), (2, 'corr')]:
    T = [r for r in rows if r['table'] == table]
    print(f"\n===== Table {table}: success = exact true pair; amplitude error = mean |rec-true|/true =====")
    print(f"{key:>5} {'n':>3} | " + ' | '.join(f"{m:>11}" for m in ['DCBF'] + M) + " | ES4 oracle")
    for v in sorted({r[key] for r in T}, reverse=True):
        R = [r for r in T if r[key] == v]
        D = [dcbf.get((table, r['cfg'], r['snr'], r['corr'], r['rep'])) for r in R]
        cells = []
        dc = [d for d in D if d is not None]
        d_succ = sum(d['found_by_powell'] for d in dc)
        d_amp = np.mean([np.abs(np.array(d['amp']) - TRUE) / TRUE for d in dc]) * 100
        cells.append(f"{d_succ:2d}/{len(dc):<2d} {d_amp:4.1f}%")
        row = dict(table=table, key=key, val=v, n=len(R),
                   DCBF=dict(succ=d_succ, n=len(dc), amp_err=d_amp,
                             ori_err=np.mean([np.abs(np.array(d['ratio']) - .5) / .5 for d in dc]) * 100,
                             sec=np.mean([1000 / d['hits'] * d['sec_per_restart'] if d['hits'] else np.nan for d in dc])))
        for m in M:
            succ = sum(r['res'][m]['exact'] for r in R)
            ok = [r for r in R if r['res'][m]['exact']]
            amp = np.mean([np.abs(np.array(r['res'][m]['amp']) - TRUE) / TRUE for r in ok]) * 100 if ok else np.nan
            ori = np.mean([np.abs(np.array(r['res'][m]['ratio']) - .5) / .5 for r in ok]) * 100 if ok else np.nan
            err = np.mean([r['res'][m]['err_mm'] for r in R])
            cells.append(f"{succ:2d}/{len(R):<2d} {amp:4.1f}%")
            row[m] = dict(succ=succ, amp_err=amp, ori_err=ori, mean_err_mm=err,
                          sec=np.mean([r['res'][m]['sec'] for r in R]))
        orc = sum(r['res']['ES4']['oracle_exact'] for r in R)
        row['ES4_oracle'] = orc
        print(f"{v:>5} {len(R):>3} | " + ' | '.join(f"{c:>11}" for c in cells) + f" | {orc}/{len(R)}")
        summary.append(row)
    print("mean localisation error over all runs (mm):",
          {m: round(np.mean([r['res'][m]['err_mm'] for r in T]), 2) for m in M})
    print("mean seconds per realisation:",
          {m: round(np.mean([r['res'][m]['sec'] for r in T]), 2) for m in M})
json.dump(summary, open('results/summary_compare.json', 'w'), indent=1, default=float)
