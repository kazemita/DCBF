import json, numpy as np
D = {(r['triple'], r['rep']): r for r in map(json.loads, open('results/three.txt'))}
E = {(r['triple'], r['rep']): r for r in map(json.loads, open('results/three2.txt'))}
print("sources found within 7 mm (one grid step) out of 3, per realisation; amplitude error over found sources")
methods = ['RS3', 'EX3', 'EX3full', 'ES4', 'ES4full']
tot = {m: [] for m in ['DCBF'] + methods}; amp = {m: [] for m in tot}; sec = {m: [] for m in tot}
for key in sorted(E):
    d, e = D[key], E[key]
    line = [f"{key[0]} rep{key[1]}"]
    dd = np.array(d['DCBF']['dist_mm']); n = int((dd <= 7.01).sum()); tot['DCBF'].append(n)
    sec['DCBF'].append(d['DCBF']['sec'])
    # DCBF amplitudes are for the 2 dipoles it returns; compare those matched within 7 mm
    line.append(f"DCBF {n}/3 {dd.round(0).tolist()}")
    for m in methods:
        dm = np.array(e[m]['dist_mm']); n = int((dm <= 7.01).sum()); tot[m].append(n)
        ok = dm <= 7.01
        if ok.any():
            a = np.array(e[m]['amp']).reshape(3, 2)[ok]; amp[m].append(np.mean(np.abs(a - [10, 20]) / [10, 20]) * 100)
        sec[m].append(e[m]['sec'])
        line.append(f"{m} {n}/3 {dm.round(0).tolist()}")
    print(' | '.join(line))
print('\nmean sources recovered (of 3):', {m: round(np.mean(v), 2) for m, v in tot.items()})
print('all three recovered:', {m: f"{sum(x == 3 for x in v)}/{len(v)}" for m, v in tot.items()})
print('amplitude error on recovered sources (%):', {m: round(np.mean(v), 1) for m, v in amp.items() if v})
print('seconds per realisation:', {m: round(np.mean(v), 2) for m, v in sec.items()})
# DCBF amplitude suppression on its two correctly-located dipoles
sup = []
for key, d in D.items():
    a = np.array(d['DCBF']['amp']).reshape(2, 2); sup.append(1 - np.mean(a / [10, 20]))
print('DCBF amplitude suppression on its 2 dipoles: %.1f%% (paper reports 47.29%%)' % (100 * np.mean(sup)))
