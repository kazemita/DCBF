"""Head-to-head: ported least-squares methods vs DCBF on the identical simulated data
(same source pairs, same seeds, same simulator) used for the Table 1 and Table 2 checks."""
import sys, time, json, numpy as np
from sim import *
from lsq_methods import *

CONFIGS = {'A': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025]),
           'B': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055]),
           'C': ([0.020, 0.030, 0.065], [0.050, -0.030, 0.030])}
MOM = np.array([[10., 20.], [10., 20.]])
N = 5000

def jobs():
    for snr in [4.0, 3.0, 2.0, 1.0, 0.50, 0.33, 0.25]:
        for cfg, reps in [('A', range(5)), ('B', [0]), ('C', [0])]:
            for rep in reps:
                yield dict(table=1, cfg=cfg, snr=snr, corr=1.0, rep=rep,
                           seed=int(1000 * snr) * 100 + rep)
    for corr in [1.0, 0.866, 0.75, 0.50]:
        for cfg in 'ABC':
            reps = (range(5) if corr == 1.0 else range(15)) if cfg == 'A' else \
                   ([0] if corr == 1.0 else range(6))
            for rep in reps:
                yield dict(table=2, cfg=cfg, snr=2.0, corr=corr, rep=rep,
                           seed=int(1000 * corr) * 100 + rep + 7_000_000)

def loc_err(found, true):
    d = np.linalg.norm(grid[found][:, None] - grid[true][None], axis=2) * 1000
    return float(min(d[0, 0] + d[1, 1], d[0, 1] + d[1, 0]) / 2)

def amps_ordered(prob, found, true):
    """LS time courses on the found pair, matched to the true dipoles' order."""
    d = np.linalg.norm(grid[found][:, None] - grid[true][None], axis=2)
    f = found if d[0, 0] + d[1, 1] <= d[0, 1] + d[1, 0] else found[::-1]
    return amp_at(prob.fit_timecourses(list(f)), 30.0)

for j in jobs():
    src = [nearest(CONFIGS[j['cfg']][0]), nearest(CONFIGS[j['cfg']][1])]
    data, C, eps = simulate(src, MOM, j['snr'], n_sig=N, n_noise=N, rng=j['seed'],
                            phases=np.array([0.0, np.arccos(j['corr'])]))
    t0 = time.time(); prob = Problem(L, data, eps, N); t_prep = time.time() - t0
    res = {}
    def rec(name, fn, extra=None):
        t = time.time(); found = sorted(fn()); dt = time.time() - t + t_prep
        a = amps_ordered(prob, found, src)
        res[name] = dict(found=found, exact=found == sorted(src), err_mm=loc_err(found, src),
                         amp=a.round(3).tolist(), ratio=[a[0] / a[1], a[2] / a[3]], sec=dt,
                         **(extra or {}))
    rec('RS', lambda: recursive_sloreta(prob, 2))
    rec('JP', lambda: joint_pair_localize(prob))
    rec('EX2', lambda: exchange_localize(prob, 2)[0])
    rec('EX2r10', lambda: exchange_localize(prob, 2, n_restarts=10, rng=j['seed'])[0])
    for R in (3, 4):
        holder = {}
        def es(R=R):
            pol, pruned, big = extra_slot_localize(prob, 2, R)
            holder.update(pruned=pruned, big=big); return pol
        rec(f'ES{R}', es)
        big = holder['big']
        d = np.linalg.norm(grid[big][:, None] - grid[src][None], axis=2) * 1000
        res[f'ES{R}'].update(pruned_exact=sorted(holder['pruned']) == sorted(src),
                             big=big, oracle_exact=bool(set(src) <= set(big)),
                             oracle_within7mm=bool((d.min(0) <= 7.01).all()))
    j.update(k=prob.k, true=sorted(src), res=res)
    print(json.dumps(j), flush=True)
