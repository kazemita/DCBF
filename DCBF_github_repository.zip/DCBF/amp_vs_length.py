"""Amplitude loss of the DCBF reconstruction at the TRUE pair as a function of data length N,
SNR and intra-pair correlation r. Compared with the empirical law (1 - m/N) * sqrt((1 + r)/2)."""
import json, numpy as np
from sim import *
from dcbf import DCBF
src = [nearest([-0.055, 0.005, 0.025]), nearest([0.055, -0.005, 0.025])]
MOM = np.array([[10., 20.], [10., 20.]]); TRUE = np.array([10, 20, 10, 20.])
m = L.shape[1]
for N in (1000, 2000, 3000, 5000, 10000, 20000):
    for snr in (4.0, 1.0, 0.25):
        for r in (1.0, 0.5):
            for rep in range(5):
                seed = 8_000_000 + N + int(100 * snr) * 10 + int(10 * r) + 1000 * rep
                data, C, eps = simulate(src, MOM, snr, n_sig=N, n_noise=N, rng=seed, phases=np.array([0, np.arccos(r)]))
                bf = DCBF(L[src], C, eps)
                p, s = bf.reconstruct(0, 1, data)
                a = amp_at(p, 30.0)
                print(json.dumps(dict(N=N, snr=snr, r=r, rep=rep, ratio=float(np.mean(a / TRUE)),
                                      pred=(1 - m / N) * np.sqrt((1 + r) / 2), Z=s['Z'])), flush=True)
