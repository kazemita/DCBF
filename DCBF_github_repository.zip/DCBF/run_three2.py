"""Least-squares methods on the identical three-source data as run_three.py (DCBF results
are taken from three.txt). Variants with and without the full-grid check."""
import json, time, numpy as np
from sim import *
from lsq_methods import *
TRIPLES = {'A3': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025], [0.020, -0.045, 0.060]),
           'B3': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055], [-0.050, -0.030, 0.040])}
MOM = np.array([[10., 20.]] * 3); PH = np.deg2rad([0.0, 22.5, 45.0]); N = 5000
def match(found, true):
    return (np.linalg.norm(grid[true][:, None] - grid[found][None], axis=2) * 1000).min(1)
for name, locs in TRIPLES.items():
    src = [nearest(x) for x in locs]
    for rep in range(5):
        seed = 5_000_000 + 100 * rep + (0 if name == 'A3' else 50)
        data, C, eps = simulate(src, MOM, 0.25, n_sig=N, n_noise=N, rng=seed, phases=PH)
        prob = Problem(L, data, eps, N)
        out = dict(triple=name, rep=rep, true=src, k=prob.k)
        variants = {'RS3': lambda: (recursive_sloreta(prob, 3), None),
                    'EX3': lambda: (exchange_localize(prob, 3)[0], None),
                    'EX3full': lambda: (exchange_localize(prob, 3, full_check=True)[0], None),
                    'ES4': lambda: extra_slot_localize(prob, 3, 4)[::2],
                    'ES4full': lambda: extra_slot_localize(prob, 3, 4, full_check=True)[::2]}
        for v, fn in variants.items():
            t = time.time(); s, big = fn(); dt = time.time() - t
            s = sorted(map(int, s))
            a = amp_at(prob.fit_timecourses(s), 30.)
            order = [int(np.argmin(np.linalg.norm(grid[s] - grid[k], axis=1))) for k in src]
            a_m = np.concatenate([a[2 * o:2 * o + 2] for o in order])
            out[v] = dict(found=s, big=big, dist_mm=match(s, src).round(1).tolist(),
                          amp=a_m.round(2).tolist(), quality=prob.quality(s), sec=dt)
        out['true_quality'] = prob.quality(src)
        print(json.dumps(out), flush=True)
