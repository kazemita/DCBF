"""Three correlated sources (paper's Fig. 1 simulation): 30 Hz, phases 0/22.5/45 deg,
SNR 0.25. DCBF (Powell, 1000 restarts) vs exchange search with 3 slots and with
4 slots (over-provisioned, pruned to 3)."""
import sys, time, json, itertools, numpy as np
from sim import *
from dcbf import DCBF, powell_search
from lsq_methods import *

TRIPLES = {'A3': ([-0.055, 0.005, 0.025], [0.055, -0.005, 0.025], [0.020, -0.045, 0.060]),
           'B3': ([-0.030, 0.045, 0.050], [0.035, -0.040, 0.055], [-0.050, -0.030, 0.040])}
MOM = np.array([[10., 20.]] * 3)
PH = np.deg2rad([0.0, 22.5, 45.0])
N = 5000
NREP = int(sys.argv[1]) if len(sys.argv) > 1 else 5

def match(found, true):
    """distance (mm) from each true source to its nearest found dipole"""
    return (np.linalg.norm(grid[true][:, None] - grid[found][None], axis=2) * 1000).min(1)

for name, locs in TRIPLES.items():
    src = [nearest(x) for x in locs]
    for rep in range(NREP):
        seed = 5_000_000 + 100 * rep + (0 if name == 'A3' else 50)
        data, C, eps = simulate(src, MOM, 0.25, n_sig=N, n_noise=N, rng=seed, phases=PH)
        out = dict(triple=name, rep=rep, true=src)
        # ---- DCBF
        bf = DCBF(L, C, eps); t = time.time()
        res, outcome, _ = powell_search(bf, 1000, rng=seed + 1)
        i, j, z = max(res, key=lambda r: r[2])
        p, sol = bf.reconstruct(i, j, data)
        out['DCBF'] = dict(found=[i, j], dist_mm=match([i, j], src).round(1).tolist(),
                           amp=amp_at(p, 30.).round(2).tolist(), sec=time.time() - t)
        # ---- exchange with 3 slots, and 4 slots pruned to 3
        prob = Problem(L, data, eps, N)
        for R in (3, 4):
            t = time.time()
            if R == 3:
                s, q = exchange_localize(prob, 3); big = s
            else:
                s, _, big = extra_slot_localize(prob, 3, 4)
            q = prob.fit_timecourses(s); a = amp_at(q, 30.)
            # amplitudes reordered to match the true sources
            order = [int(np.argmin(np.linalg.norm(grid[s] - grid[k], axis=1))) for k in src]
            a_m = np.concatenate([a[2 * o:2 * o + 2] for o in order])
            out[f'EX{R}'] = dict(found=list(map(int, s)), big=list(map(int, big)),
                                 dist_mm=match(s, src).round(1).tolist(),
                                 amp=a_m.round(2).tolist(), k=prob.k, sec=time.time() - t)
        print(json.dumps(out), flush=True)
